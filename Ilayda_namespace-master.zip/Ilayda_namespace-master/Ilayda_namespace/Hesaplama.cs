﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ilayda_namespace
{
    public class Hesaplama
    {
        public int sayiToplam(int sayi1, int sayi2)
        {
            return sayi1 + sayi2;
        }
        public int sayiCarp(int sayi1, int sayi2)
        {
            return sayi1 * sayi2;
        }

    }
}
